const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const programRoutes = require('./routes/programRoutes');
const db = require('./config/db'); // 데이터베이스 설정을 불러옴

dotenv.config();

const app = express();
app.use(express.json());

// Static file serving
app.use(express.static(path.join(__dirname, 'frontend')));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/programs', programRoutes);

// 기본 루트 경로에 대한 핸들러 추가
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// 이메일 인증 성공 페이지
app.get('/verify-success', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'verify.html'));
});

// 관리자 페이지
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'frontend', 'admin.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
