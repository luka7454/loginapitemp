const mariadb = require('mariadb');
const dotenv = require('dotenv');

// .env 파일에서 환경 변수를 로드합니다.
dotenv.config();

console.log("NODE_ENV:", process.env.NODE_ENV);
console.log("DB_HOST:", process.env.DB_HOST);
console.log("DB_PORT:", process.env.DB_PORT);
console.log("DB_USER:", process.env.DB_USER);
console.log("DB_PASS:", process.env.DB_PASS);
console.log("DB_NAME:", process.env.DB_NAME);
console.log("JWT_SECRET:", process.env.JWT_SECRET);
console.log("EMAIL_USER:", process.env.EMAIL_USER);
console.log("EMAIL_PASS:", process.env.EMAIL_PASS);
console.log("BASE_URL:", process.env.BASE_URL);

const pool = mariadb.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  connectionLimit: 5
});

pool.getConnection()
  .then(conn => {
    console.log('Database connected!');
    conn.release();
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err.message);
  });

module.exports = pool;
