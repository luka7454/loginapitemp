function generateLicenseKey() {
    return 'xxxx-xxxx-xxxx-xxxx'.replace(/[x]/g, function() {
      return (Math.random() * 36 | 0).toString(36);
    }).toUpperCase();
  }
  
  module.exports = generateLicenseKey;
  