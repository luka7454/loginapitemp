const UserModel = require('../models/userModel');

async function getUserProfile(req, res) {
  try {
    const email = req.user.email; // 요청에서 email을 가져옴
    const user = await UserModel.getUserByEmail(email);
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function getAllUsers(req, res) {
  try {
    const users = await UserModel.getAllUsers();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function createUser(req, res) {
  const { email, password, points, paymentStatus, verified } = req.body;
  const newUser = { email, password, points, paymentStatus, verified };

  try {
    await UserModel.createUser(newUser);
    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error creating user.', error });
  }
}

async function updateUser(req, res) {
  const { email } = req.params;
  const updates = req.body;

  try {
    await UserModel.updateUser(email, updates);
    res.status(200).json({ message: 'User updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating user.', error });
  }
}

async function deleteUser(req, res) {
  const { email } = req.params;

  try {
    await UserModel.deleteUser(email);
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting user.', error });
  }
}

async function getPaymentStatus(req, res) {
  try {
    const email = req.params.email;
    const paymentStatus = await UserModel.getPaymentStatusByEmail(email);
    res.status(200).json({ paymentStatus });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function getPoints(req, res) {
  try {
    const email = req.params.email;
    const points = await UserModel.getPointsByEmail(email);
    res.status(200).json({ points });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

async function deductPoints(req, res) {
  try {
    const email = req.params.email;
    const pointsToDeduct = 100;
    const success = await UserModel.deductPoints(email, pointsToDeduct);
    if (success) {
      res.status(200).json({ message: 'Points deducted successfully' });
    } else {
      res.status(400).json({ message: 'Insufficient points' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getUserProfile,
  getAllUsers,
  createUser,
  updateUser,
  deleteUser,
  getPaymentStatus,
  getPoints,
  deductPoints,
};
