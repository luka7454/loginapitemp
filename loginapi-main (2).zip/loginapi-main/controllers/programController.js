const programModel = require('../models/programModel');
const licenseModel = require('../models/licenseModel');
const generateLicenseKey = require('../utils/generateLicenseKey');

async function createProgram(req, res) {
  const userId = req.user.userId;
  const { name, expiry_date } = req.body;
  const newProgram = {
    user_id: userId,
    name,
    expiry_date
  };

  try {
    await programModel.createProgram(newProgram);
    res.status(201).json({ message: 'Program created successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Error creating program.', error });
  }
}

async function createLicense(req, res) {
  const { program_id, expiry_date } = req.body;
  const licenseKey = generateLicenseKey();
  const newLicense = {
    program_id,
    license_key: licenseKey,
    expiry_date
  };

  try {
    await licenseModel.createLicense(newLicense);
    res.status(201).json({ message: 'License created successfully.', licenseKey });
  } catch (error) {
    res.status(500).json({ message: 'Error creating license.', error });
  }
}

module.exports = {
  createProgram,
  createLicense
};
