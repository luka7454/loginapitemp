const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const userModel = require('../models/userModel');
const transporter = require('../config/mailConfig');

async function register(req, res) {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = {
    email,
    password: hashedPassword,
    points: 0,
    verified: false
  };

  try {
    await userModel.createUser(newUser);
    const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1h' });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Email Verification',
      text: `Please verify your email by clicking on the following link: ${process.env.BASE_URL}/api/auth/verify/${token}`
    };

    await transporter.sendMail(mailOptions);

    res.status(201).json({ message: 'User registered. Please verify your email.' });
  } catch (error) {
    res.status(500).json({ message: 'Error registering user.', error });
  }
}

async function login(req, res) {
  const { email, password } = req.body;
  try {
    const user = await userModel.getUserByEmail(email);
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password.' });
    }

    const token = jwt.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  } catch (error) {
    res.status(500).json({ message: 'Error logging in.', error });
  }
}

async function verifyEmail(req, res) {
  const { token } = req.params;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    await userModel.verifyUser(decoded.email);
    res.status(200).send('Email verified successfully. You can now log in.');
  } catch (error) {
    res.status(500).json({ message: 'Invalid or expired token.', error });
  }
}

module.exports = {
  register,
  login,
  verifyEmail
};
