const pool = require('../config/db');

async function createProgram(program) {
  const conn = await pool.getConnection();
  const sql = `INSERT INTO programs (user_id, name, expiry_date) VALUES (?, ?, ?)`;
  const values = [program.user_id, program.name, program.expiry_date];
  await conn.query(sql, values);
  conn.release();
}

// 기타 필요한 함수들...

module.exports = {
  createProgram,
  // 기타 함수들...
};
