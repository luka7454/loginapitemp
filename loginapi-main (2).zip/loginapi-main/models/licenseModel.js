const pool = require('../config/db');

async function createLicense(license) {
  const conn = await pool.getConnection();
  const sql = `INSERT INTO licenses (program_id, license_key, expiry_date) VALUES (?, ?, ?)`;
  const values = [license.program_id, license.license_key, license.expiry_date];
  await conn.query(sql, values);
  conn.release();
}

// 기타 필요한 함수들...

module.exports = {
  createLicense,
  // 기타 함수들...
};
