const pool = require('../config/db');

async function createUser(user) {
  const conn = await pool.getConnection();
  const sql = `INSERT INTO users (email, password, points, paymentStatus, verified) VALUES (?, ?, ?, ?, ?)`;
  const values = [user.email, user.password, user.points, user.paymentStatus, user.verified];
  await conn.query(sql, values);
  conn.release();
}

async function getAllUsers() {
  const conn = await pool.getConnection();
  const sql = `SELECT * FROM users`;
  const rows = await conn.query(sql);
  conn.release();
  return rows;
}

async function getUserByEmail(email) {
  const conn = await pool.getConnection();
  const sql = `SELECT * FROM users WHERE email = ?`;
  const rows = await conn.query(sql, [email]);
  conn.release();
  return rows[0];
}

async function updateUser(email, updates) {
  const conn = await pool.getConnection();
  const sql = `UPDATE users SET ? WHERE email = ?`;
  await conn.query(sql, [updates, email]);
  conn.release();
}

async function deleteUser(email) {
  const conn = await pool.getConnection();
  const sql = `DELETE FROM users WHERE email = ?`;
  await conn.query(sql, [email]);
  conn.release();
}

async function getPaymentStatusByEmail(email) {
  const conn = await pool.getConnection();
  const sql = `SELECT paymentStatus FROM users WHERE email = ?`;
  const rows = await conn.query(sql, [email]);
  conn.release();
  return rows[0].paymentStatus;
}

async function getPointsByEmail(email) {
  const conn = await pool.getConnection();
  const sql = `SELECT points FROM users WHERE email = ?`;
  const rows = await conn.query(sql, [email]);
  conn.release();
  return rows[0].points;
}

async function deductPoints(email, points) {
  const conn = await pool.getConnection();
  const sql = `UPDATE users SET points = points - ? WHERE email = ? AND points >= ?`;
  const values = [points, email, points];
  const [result] = await conn.query(sql, values);
  conn.release();
  return result.affectedRows > 0; // 포인트가 차감되었는지 여부 반환
}

module.exports = {
  createUser,
  getAllUsers,
  getUserByEmail,
  updateUser,
  deleteUser,
  getPaymentStatusByEmail,
  getPointsByEmail,
  deductPoints,
};
