const express = require('express');
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

// 기존 라우트
router.get('/profile', authMiddleware, userController.getUserProfile);

// 새로운 라우트
router.get('/', authMiddleware, userController.getAllUsers);
router.post('/', authMiddleware, userController.createUser);
router.put('/:email', authMiddleware, userController.updateUser);
router.delete('/:email', authMiddleware, userController.deleteUser);
router.get('/payment-status/:email', authMiddleware, userController.getPaymentStatus);
router.get('/points/:email', authMiddleware, userController.getPoints);
router.post('/deduct-points/:email', authMiddleware, userController.deductPoints);

module.exports = router;
