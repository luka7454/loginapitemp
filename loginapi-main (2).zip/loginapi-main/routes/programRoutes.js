const express = require('express');
const programController = require('../controllers/programController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', authMiddleware, programController.createProgram);
router.post('/license', authMiddleware, programController.createLicense);

module.exports = router;
